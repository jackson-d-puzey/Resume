# Jackson Puzey — Personal Website

Personal resume website hosted via GitHub Pages.

## How to update

1. Edit `index.html`
2. Commit and push to `main`
3. GitHub Pages will automatically redeploy

## Setup (first time)

1. Go to your repository **Settings → Pages**
2. Under **Source**, select **Deploy from a branch**
3. Choose **main** branch, **/ (root)** folder
4. Click **Save** — your site will be live at `https://your-username.github.io/your-repo-name`
